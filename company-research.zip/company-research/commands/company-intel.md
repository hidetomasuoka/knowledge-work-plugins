---
description: 企業URLを渡して、知りたい情報をインタラクティブに選択しながら調査する。使い方: /company-research:company-intel [URL]
---

企業の調査を開始します。

$ARGUMENTS にURLが含まれている場合はそのURLを対象企業として使用してください。URLが含まれていない場合は、調査したい企業のURLを聞いてください。

その後、**company-intel スキル**の手順に従い、必ずStep 2のインタラクティブな情報カテゴリ選択を行ってから調査を開始してください。
